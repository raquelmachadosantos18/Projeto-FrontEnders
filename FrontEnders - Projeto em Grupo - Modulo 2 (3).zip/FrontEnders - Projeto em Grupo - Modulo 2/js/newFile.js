chk.addEventListener('click', () => {
    contato.classList.toggle('dark');
});
